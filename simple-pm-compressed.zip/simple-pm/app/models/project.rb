class Project < ApplicationRecord
  has_many :tasks
  belongs_to :user

  def badge_color
    case status
    	when 'not-started'
    	  'secondary'
    	when 'in-progress'
    	   'info'
    	when 'completed'
    	   'success'
    	end
  end
  
  def status
  	return 'not-started' if tasks.none?

  	if tasks.all? { |task| task.completed? }
  		'completed'
    elsif tasks.any? { |task| task.in_progress? }
  		'in-progress'
    else
        'not-started'
    end
  end   

  def percent_completed
    return 0 if tasks.none?
    ((total_completed.to_f / total_tasks) * 100).round   				
  end

  def total_completed 
    tasks.select { |task| task.completed? }.count
  end
  
  def total_tasks
    tasks.count
  end  	
end
